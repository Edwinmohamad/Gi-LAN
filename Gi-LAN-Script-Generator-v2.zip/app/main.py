from flask import Flask, render_template, request, send_file, redirect, url_for, flash
import os, datetime

app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = 'change-me-please'

# Output inside container mapped to host /home/casaos/Downloads
OUTPUT_DIR = "/app/output"
os.makedirs(OUTPUT_DIR, exist_ok=True)

GROUPS = {
    "GYG & HRM (10.76.129.165)": ["10.76.129.165"],
    "CDLV, CRB & TBS (10.74.166.195)": ["10.74.166.195"],
    "BRN & BSD (10.52.141.165)": ["10.52.141.165"]
}

@app.route('/', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        app_name = request.form.get('app_name','').strip()
        crt = request.form.get('crt_name','').strip()
        key = request.form.get('key_name','').strip()
        ca = request.form.get('ca_name','').strip()
        group = request.form.get('group')
        include_update = True if request.form.get('include_update')=='on' else False
        ssl_line = request.form.get('ssl_line','').strip()

        if not app_name or not crt or not key or not ca or not group:
            flash('Semua field harus diisi.', 'danger')
            return redirect(url_for('index'))

        ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{app_name}_ssl_update_{ts}.sh"
        outpath = os.path.join(OUTPUT_DIR, filename)
        lines = []
        lines.append("#!/bin/bash")
        lines.append(f"# Gi-LAN Script Generator - app: {app_name}")
        lines.append(f"# Generated: {datetime.datetime.now().isoformat()}")
        lines.append("set -euo pipefail")
        lines.append("")
        lines.append("# Config variables (edit if needed)")
        lines.append("OAM_IP=192.168.23.1")
        lines.append("STAGING=/staging/New_Certs")
        lines.append("CERTDIR=/opt/opwv/integra/8.4/tools/certs")
        lines.append("SSL_CONF=/opt/opwv/integra/8.4/tools/trafficserver/etc/trafficserver/ssl_multicert.config")
        lines.append("")
        lines.append(f"CAFILE={ca}")
        lines.append(f"CRTFILE={crt}")
        lines.append(f"KEYFILE={key}")
        lines.append("")
        lines.append("# STEP 1 - Upload to OAM (manual)")
        lines.append('echo "Run this on your workstation to upload files to OAM:"')
        lines.append('echo "scp -p ${CAFILE} ${CRTFILE} ${KEYFILE} root@${OAM_IP}:${STAGING}"')
        lines.append("")
        # Group mapping
        lines.append("# IP grouping -> hostnames") 
        # build grouping in script
        for ip, hosts in {ip:hosts for k,hosts in {}.items()}.items():
            pass
        # We'll inject grouping based on selected group only
        selected_ips = GROUPS.get(group, [])
        lines.append("declare -A hosts_grouped")
        # Only include selected group's mapping
        for ip in selected_ips:
            # host names: derive simple names from group label
            # We'll fetch hostnames by mapping: use pre-known mapping
            hostnames = []
            for label, ips in GROUPS.items():
                if ip in ips:
                    # extract names from label before parentheses
                    names = label.split('(')[0].strip()
                    hostnames = names.replace(' & ', ' ').replace(',', '').split()
                    break
            host_list = " ".join(hostnames)
            lines.append(f'hosts_grouped["{ip}"]="{host_list}"')
        lines.append("")
        lines.append("# STEP 2 - Backup and staging commands (template)")
        lines.append('for ip in "${!hosts_grouped[@]}"; do')
        lines.append('  echo "===== Node group: $ip -> ${hosts_grouped[$ip]} ====="')
        lines.append('  for h in ${hosts_grouped[$ip]}; do')
        lines.append('    echo "Preparing $h on $ip"')
        lines.append('  done')
        lines.append('done')
        lines.append("")
        lines.append("# STEP 3 - Commands to run per IP (copy these to run on OAM or node)")
        lines.append('for ip in "${!hosts_grouped[@]}"; do')
        lines.append('  echo "---- on $ip ----"')
        lines.append('  echo "mkdir -p /staging/backup_old_certificates_$(date +%Y%m%d)"')
        lines.append('  echo "cp -r $CERTDIR/* /staging/backup_old_certificates_$(date +%Y%m%d)/"')
        lines.append('  echo "mv $CERTDIR/*${CRTFILE%.*}* /staging/old_certificates_$(date +%Y%m%d)/ 2>/dev/null || true"')
        lines.append('  echo "scp -p root@${OAM_IP}:${STAGING}/${CAFILE} root@${OAM_IP}:${STAGING}/${CRTFILE} root@${OAM_IP}:${STAGING}/${KEYFILE} $ip:$CERTDIR/"')
        lines.append('  echo "chown opwv:opwv $CERTDIR/${CAFILE} $CERTDIR/${CRTFILE} $CERTDIR/${KEYFILE} && chmod 644 $CERTDIR/*.crt $CERTDIR/*.key"')
        lines.append('  echo "openssl x509 -noout -subject -issuer -in $CERTDIR/${CRTFILE} || true"')
        if include_update and ssl_line:
            safe = ssl_line.replace('"', '\"')
            lines.append(f'  echo "Apply ssl_multicert line (append/replace): {safe}"')
            lines.append('  echo "sed -i \"/dest_ip=/d\" $SSL_CONF || true"')
            lines.append(f'  echo "echo \"{safe}\" >> $SSL_CONF"')
        lines.append('done')
        lines.append("")
        lines.append('echo "Review generated commands above. Run on OAM or respective nodes as needed."')

        with open(outpath, "w") as fh:
            fh.write("\n".join(lines))
        os.chmod(outpath, 0o755)
        flash(f"Script generated: {filename} and saved to /home/casaos/Downloads/", "success")
        return redirect(url_for('index'))

    return render_template('index.html', groups=GROUPS, app_title='Gi-LAN Script Generator')

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8080)
