from flask import Flask, render_template, request
import os
from datetime import datetime

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        filename = f"/downloads/Gi-LAN_Script_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sh"
        with open(filename, "w") as f:
            f.write("""#!/bin/bash
# Gi-LAN SSL Certificate Deployment Tutor

🧩 STEP 1 — Persiapan & Upload File
Ganti proxy site yang dituju (sesuai site update)
Backup file INTEGRA & OAM via GUI (All Site)
Upload file cert baru ke ignusr, lalu copy ke OAM server:
scp -r DigiCertCA_roli_telkomsel_com.crt \\
   _Common_roli2024_444527_1.crt \\
   _Common_roli2024_444536_1.key \\
   root@192.168.23.1:/staging/New_Certs
chmod 755 * && chown opwv:opwv *

🧩 STEP 2 — Backup & Update Konfigurasi SSL
for h in $(egrep -i "fe|vos" /etc/hosts | sort -k1 | awk '{print $2}'); do
  ssh -q $h "hostname; cp /opt/opwv/integra/8.4/tools/trafficserver/etc/trafficserver/ssl_multicert.config \\
  /opt/opwv/integra/8.4/tools/trafficserver/etc/trafficserver/ssl_multicert.config.bak-$(date +%Y%m%d%H%M%S)"
done

🧩 STEP 3 — Backup Certificate Lama
for h in $(egrep -i "fe|vos" /etc/hosts | sort -k1 | awk '{print $2}'); do
  ssh -q $h "hostname; mkdir -p /staging/backup_old_certificates_$(date +%Y%m%d); \\
  cp -r /opt/opwv/integra/8.4/tools/certs/* /staging/backup_old_certificates_$(date +%Y%m%d)"
done

🧩 STEP 4 — Deploy Certificate Baru ke Semua Node
for h in $(egrep -i "fe|vos" /etc/hosts | sort -k1 | awk '{print $2}'); do
  scp -p /staging/New_Certs/DigiCertCA_roli_telkomsel_com.crt \\
         /staging/New_Certs/_Common_roli2024_444527_1.crt \\
         /staging/New_Certs/_Common_roli2024_444536_1.key \\
         $h:/opt/opwv/integra/8.4/tools/certs/
done

🧩 STEP 5 — Set Permission di Semua Node
for h in $(egrep -i "fe|vos" /etc/hosts | sort -k1 | awk '{print $2}'); do
  ssh -q $h "hostname; chown opwv:opwv /opt/opwv/integra/8.4/tools/certs/*.crt /opt/opwv/integra/8.4/tools/certs/*.key; chmod 644 /opt/opwv/integra/8.4/tools/certs/*"
done

🧩 STEP 6 — Validasi Certificate Baru
for h in $(egrep -i "fe|vos" /etc/hosts | sort -k1 | awk '{print $2}'); do
  ssh -q $h "hostname; openssl x509 -enddate -noout -in /opt/opwv/integra/8.4/tools/certs/_Common_roli2024_444527_1.crt"
done

🧩 STEP 7 — Restart Service / Node
/etc/init.d/oamsca-v8.4 restart
""")
        return f"✅ Script berhasil dibuat di {filename}"
    return render_template("index.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
