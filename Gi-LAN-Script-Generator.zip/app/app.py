\
    from flask import Flask, render_template, request, send_file, redirect, url_for, flash
    import os, tempfile, datetime, yaml, pathlib

    APP_DIR = os.path.dirname(os.path.abspath(__file__))
    OUTPUT_DIR = os.path.join(APP_DIR, "output")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.secret_key = os.environ.get("FLASK_SECRET", "change-me-please")

    NODES_FILE = os.path.join(os.path.dirname(APP_DIR), "nodes.yaml")

    def load_nodes():
        if not os.path.exists(NODES_FILE):
            return {}
        import yaml
        with open(NODES_FILE, "r") as fh:
            return yaml.safe_load(fh) or {}

    @app.route("/", methods=["GET","POST"])
    def index():
        nodes = load_nodes()
        sites = sorted(nodes.keys())
        if request.method == "POST":
            app_name = request.form.get("app_name","").strip()
            crt_name = request.form.get("crt_name","").strip()
            key_name = request.form.get("key_name","").strip()
            ca_name  = request.form.get("ca_name","").strip()
            selected_sites = request.form.getlist("sites")
            include_update_ssl = bool(request.form.get("include_update_ssl"))
            ssl_line = request.form.get("ssl_multicert_line","").strip()

            if not app_name or not crt_name or not key_name or not ca_name:
                flash("Please fill all fields (App name, CRT, KEY, CA).", "danger")
                return redirect(url_for("index"))
            if not selected_sites:
                flash("Select at least one site.", "danger")
                return redirect(url_for("index"))

            ts = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            fname = f"update_ssl_{app_name}_{ts}.sh"
            outpath = os.path.join(OUTPUT_DIR, fname)

            # build script content
            lines = []
            lines.append("#!/bin/bash")
            lines.append(f"# Gi-LAN generated deploy script for app: {app_name}")
            lines.append(f"# Generated: {datetime.datetime.now().isoformat()}")
            lines.append("set -euo pipefail")
            lines.append("")
            lines.append("# CONFIG - change target OAM upload IP if different")
            lines.append("OAM_IP=192.168.23.1")
            lines.append("STAGING=/staging/New_Certs")
            lines.append("CERTDIR=/opt/opwv/integra/8.4/tools/certs")
            lines.append("SSL_CONF=/opt/opwv/integra/8.4/tools/trafficserver/etc/trafficserver/ssl_multicert.config")
            lines.append("")
            lines.append("# Files to upload (local -> OAM staging)")
            lines.append(f"CAFILE={ca_name}")
            lines.append(f"CRTFILE={crt_name}")
            lines.append(f"KEYFILE={key_name}")
            lines.append("")
            lines.append("# STEP 1 - Upload to OAM (manual command template)")
            lines.append("echo \"STEP 1: Upload new cert files to OAM staging:\"")
            lines.append('echo "scp -p ${CAFILE} ${CRTFILE} ${KEYFILE} root@${OAM_IP}:${STAGING}"')
            lines.append("")
            lines.append("# IP grouping (ip => hostnames)")
            nodes_map = load_nodes()
            # build grouping mapping
            ip_groups = {}
            for site in selected_sites:
                for h in nodes_map.get(site, {}).get("hosts", []):
                    ip = h.get("ip")
                    name = h.get("name")
                    if not ip: continue
                    ip_groups.setdefault(ip, []).append(name)
            lines.append("declare -A hosts_grouped")
            for ip, hosts in ip_groups.items():
                host_list = " ".join(hosts)
                lines.append(f'hosts_grouped["{ip}"]="{host_list}"')
            lines.append("")
            lines.append("")
            lines.append("# STEP 2 - Backup ssl_multicert.config on each node and backup existing certs")
            lines.append('for ip in "${!hosts_grouped[@]}"; do')
            lines.append('  echo "Node group: $ip -> ${hosts_grouped[$ip]}"')
            lines.append('  for h in ${hosts_grouped[$ip]}; do')
            lines.append('    echo "  - Preparing $h ($ip)"')
            lines.append('  done')
            lines.append('done')
            lines.append("")
            lines.append("# STEP 3 - Commands to run per IP (template - manual execution)")
            lines.append('for ip in "${!hosts_grouped[@]}"; do')
            lines.append('  echo "==== on $ip ===="')
            lines.append('  echo "mkdir -p /staging/backup_old_certificates_$(date +%Y%m%d)"')
            lines.append('  echo "cp -r $CERTDIR/* /staging/backup_old_certificates_$(date +%Y%m%d)/"')
            lines.append('  echo "mv $CERTDIR/*roli* /staging/old_certificates_$(date +%Y%m%d)/ 2>/dev/null || true"')
            lines.append('  echo "scp -p ${OAM_IP}:${STAGING}/${CAFILE} ${OAM_IP}:${STAGING}/${CRTFILE} ${OAM_IP}:${STAGING}/${KEYFILE} $ip:$CERTDIR/"')
            lines.append('  echo "chown opwv:opwv $CERTDIR/${CAFILE} $CERTDIR/${CRTFILE} $CERTDIR/${KEYFILE} && chmod 644 $CERTDIR/*.crt $CERTDIR/*.key"')
            lines.append('  echo "openssl x509 -noout -subject -issuer -in $CERTDIR/${CRTFILE} || true"')
            if include_update_ssl and ssl_line:
                safe_line = ssl_line.replace('"', '\\"')
                lines.append(f'  echo "Update ssl_multicert (append/replace): {safe_line}"')
                lines.append('  echo "sed -i \\"/dest_ip=/d\\" $SSL_CONF || true"')
                lines.append(f'  echo "echo \\"{safe_line}\\" >> $SSL_CONF"')
            lines.append('done')
            lines.append("")
            lines.append('echo "Script generation complete. Review the commands above and run them where appropriate."')

            with open(outpath, "w") as fh:
                fh.write("\n".join(lines))
            os.chmod(outpath, 0o755)
            return send_file(outpath, as_attachment=True)

        return render_template("index.html", sites=sites, app_title="Gi-LAN Script Generator")

    if __name__ == "__main__":
        app.run(host="0.0.0.0", port=8080)
