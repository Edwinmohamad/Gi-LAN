# Gi-LAN Script Generator

Dockerized Flask web app that generates full SSL deployment scripts for Gi-LAN nodes.
This package contains a GUI (dark mode) web app that only *generates* scripts (.sh).
It does NOT execute any SSH or remote commands.

## How to run (CasaOS / Docker)
1. Upload the folder to your CasaOS (e.g. `~/gi-lan-script-generator`).
2. From the folder, run:
   ```bash
   docker compose up -d --build
   ```
3. Open browser: `http://<CASAOS_IP>:8080`

## Output
Generated script files are written inside the container to `/app/output` which is
mounted to the host folder `./app/output`. The README assumes you run from the project root;
the generated `.sh` files will appear under `app/output/` and can be moved to `/home/casaos/Downloads/`.

## Notes
- Edit `app/templates/index.html` and `app/static/style.css` if you want theme changes.
- Always review generated script before running on production.
